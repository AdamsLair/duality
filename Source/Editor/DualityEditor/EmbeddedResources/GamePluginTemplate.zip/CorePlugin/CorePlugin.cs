﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality;

namespace __Namespace__
{
	/// <summary>
	/// Defines a Duality core plugin.
	/// </summary>
	public class __CorePluginClassName__ : CorePlugin
	{
		// Override methods here for global logic
	}
}
