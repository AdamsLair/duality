﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality;

namespace Debug
{
	/// <summary>
	/// Defines a Duality core plugin.
	/// </summary>
    public class DebugCorePlugin : CorePlugin
    {
		// Override methods here for global logic
    }
}
