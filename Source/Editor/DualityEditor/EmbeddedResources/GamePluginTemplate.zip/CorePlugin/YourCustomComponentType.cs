﻿using System;
using System.Collections.Generic;
using System.Linq;

using Duality;

namespace __Namespace__
{
	public class YourCustomComponentType : Component
	{
		
	}
}
